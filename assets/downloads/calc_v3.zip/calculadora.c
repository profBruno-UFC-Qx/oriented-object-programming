//
// Created by Bruno Mateus on 14/05/21.
//
float divisao(float operando1, float operando2) { return operando1 / operando2; }

float multiplicacao(float operando1, float operando2) { return operando1 * operando2; }

float substracao(float operando1, float operando2) { return operando1 - operando2; }

float soma(float operando1, float operando2) { return operando1 + operando2; }
